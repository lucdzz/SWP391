/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author lucdz
 */
public class Constants {

    public static String GOOGLE_CLIENT_ID = "109794047746-vkf1iea5apg8q9tfrl9kuca6hh6mm7ih.apps.googleusercontent.com";
    public static String GOOGLE_CLIENT_SECRET = "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";
    public static String GOOGLE_REDIRECT_URI = "http://localhost:9999/SWP391/login";
    public static String GOOGLE_LINK_GET_TOKEN = "https://oauth2.googleapis.com/token";

    public static String GOOGLE_LINK_GET_USER_INFO = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=";
    public static String GOOGLE_GRANT_TYPE = "authorization_code";
}
