/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author lucdz
 */


public class Student {
    private String username;
    private String password;
    private String name;
    private String email;
    private String date_of_birth;
    private String managed_by_manager;
    private String google_id;

    public Student() {
    }

    public Student(String username, String password, String name, String email, String date_of_birth, String managed_by_manager, String google_id) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.date_of_birth = date_of_birth;
        this.managed_by_manager = managed_by_manager;
        this.google_id = google_id;
    }

    // Getter và Setter cho các thuộc tính
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDateOfBirth() {
        return date_of_birth;
    }

    public void setDateOfBirth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public String getManagedByManager() {
        return managed_by_manager;
    }

    public void setManagedByManager(String managed_by_manager) {
        this.managed_by_manager = managed_by_manager;
    }

    public String getGoogleId() {
        return google_id;
    }

    public void setGoogleId(String google_id) {
        this.google_id = google_id;
    }

    @Override
    public String toString() {
        return "Student{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", date_of_birth='" + date_of_birth + '\'' +
                ", managed_by_manager='" + managed_by_manager + '\'' +
                ", google_id='" + google_id + '\'' +
                '}';
    }
}

