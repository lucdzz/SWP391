/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author lucdz
 */
public class Manager {
    private String username;
    private String password;
    private String name;
    private String email;
    private String managed_by_admin;
    private String google_id;

    public Manager() {
    }

    public Manager(String username, String password, String name, String email, String managed_by_admin, String google_id) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.managed_by_admin = managed_by_admin;
        this.google_id = google_id;
    }

    // Getter và Setter cho các thuộc tính
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getManagedByAdmin() {
        return managed_by_admin;
    }

    public void setManagedByAdmin(String managed_by_admin) {
        this.managed_by_admin = managed_by_admin;
    }

    public String getGoogleId() {
        return google_id;
    }

    public void setGoogleId(String google_id) {
        this.google_id = google_id;
    }

    @Override
    public String toString() {
        return "Manager{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", managed_by_admin='" + managed_by_admin + '\'' +
                ", google_id='" + google_id + '\'' +
                '}';
    }
}

