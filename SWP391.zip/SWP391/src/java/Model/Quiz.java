/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.List;

/**
 *
 * @author lucdz
 */
public class Quiz {
    
    private String quizId,classId,courseCode,semesterName,quizName,quizDate,quizDuration,quizType;
    List<Question> questions;

    public Quiz() {
    }

    public Quiz(String quizId, String classId, String courseCode, String semesterName, String quizName, String quizDate, String quizDuration, String quizType, List<Question> questions) {
        this.quizId = quizId;
        this.classId = classId;
        this.courseCode = courseCode;
        this.semesterName = semesterName;
        this.quizName = quizName;
        this.quizDate = quizDate;
        this.quizDuration = quizDuration;
        this.quizType = quizType;
        this.questions = questions;
    }

    public String getQuizId() {
        return quizId;
    }

    public void setQuizId(String quizId) {
        this.quizId = quizId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getSemesterName() {
        return semesterName;
    }

    public void setSemesterName(String semesterName) {
        this.semesterName = semesterName;
    }

    public String getQuizName() {
        return quizName;
    }

    public void setQuizName(String quizName) {
        this.quizName = quizName;
    }

    public String getQuizDate() {
        return quizDate;
    }

    public void setQuizDate(String quizDate) {
        this.quizDate = quizDate;
    }

    public String getQuizDuration() {
        return quizDuration;
    }

    public void setQuizDuration(String quizDuration) {
        this.quizDuration = quizDuration;
    }

    public String getQuizType() {
        return quizType;
    }

    public void setQuizType(String quizType) {
        this.quizType = quizType;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }
    
    
}
