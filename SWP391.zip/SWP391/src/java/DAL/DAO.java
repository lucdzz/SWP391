package DAL;

import Model.Admin;
import Model.Course;
import Model.Manager;
import Model.Semester;
import Model.Student;
import Model.Teacher;
import Model.Class;
import Model.Question;
import Model.Quiz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAO extends DBContext {

    /**
     *
     * @param googleId
     * @return
     */
    public Object authenticateUser(String googleId) {
        Object user = null;
        // Check Admin
        user = authenticateAdmin(googleId);
        if (user != null) {
            return user;
        }
        // Check Manager
        user = authenticateManager(googleId);
        if (user != null) {
            return user;
        }
        // Check Teacher
        user = authenticateTeacher(googleId);
        if (user != null) {
            return user;
        }
        // Check Student
        user = authenticateStudent(googleId);
        return user;
    }

    /**
     *
     * @param googleId
     * @return
     */
    public Admin authenticateAdmin(String googleId) {
        String sql = "SELECT * FROM Admin WHERE google_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, googleId);

            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                return new Admin(username, password, name, email, googleId);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     *
     * @param googleId
     * @return
     */
    public Manager authenticateManager(String googleId) {
        String sql = "SELECT * FROM Manager WHERE google_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, googleId);

            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String managedByAdmin = resultSet.getString("managed_by_admin");
                return new Manager(username, password, name, email, managedByAdmin, googleId);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     *
     * @param googleId

     * @return
     */
    public Teacher authenticateTeacher(String googleId) {
        String query = "SELECT * FROM Teacher WHERE google_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, googleId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String department = resultSet.getString("department");
                String managedByManager = resultSet.getString("managed_by_manager");
                return new Teacher(username, password, name, email, department, managedByManager, googleId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *
     * @param googleId

     * @return
     */
    public Student authenticateStudent(String googleId) {
        String query = "SELECT * FROM Student WHERE google_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, googleId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String dateOfBirth = resultSet.getString("date_of_birth");
                String managedByManager = resultSet.getString("managed_by_manager");
                return new Student(username, password, name, email, dateOfBirth, managedByManager, googleId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /////Login
    public boolean checkGoogleIdExists(String googleId) {
        String query = "SELECT google_id FROM Admin WHERE google_id = ? "
                + "UNION ALL "
                + "SELECT google_id FROM Manager WHERE google_id = ? "
                + "UNION ALL "
                + "SELECT google_id FROM Teacher WHERE google_id = ? "
                + "UNION ALL "
                + "SELECT google_id FROM Student WHERE google_id = ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, googleId);
            ps.setString(2, googleId);
            ps.setString(3, googleId);
            ps.setString(4, googleId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String getUserRoleByGoogleId(String googleId) {
        String query = "SELECT 'Admin' AS role FROM Admin WHERE google_id = ? "
                + "UNION ALL "
                + "SELECT 'Manager' AS role FROM Manager WHERE google_id = ? "
                + "UNION ALL "
                + "SELECT 'Teacher' AS role FROM Teacher WHERE google_id = ? "
                + "UNION ALL "
                + "SELECT 'Student' AS role FROM Student WHERE google_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, googleId);
            ps.setString(2, googleId);
            ps.setString(3, googleId);
            ps.setString(4, googleId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("role");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //////////admin
    public List<Manager> getAllManagers() {
        List<Manager> managers = new ArrayList<>();
        String sql = "SELECT * FROM Manager";
        try (PreparedStatement st = connection.prepareStatement(sql); ResultSet rs = st.executeQuery()) {

            while (rs.next()) {
                Manager manager = new Manager(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("managed_by_admin"),
                        rs.getString("google_id")
                );
                managers.add(manager);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return managers;
    }

    ///////Semester
//    public boolean createSemester(String semesterName, String startDate, String endDate) {
//        String sql = "INSERT INTO Semester (semester_name, start_date, end_date) VALUES (?, ?, ?)";
//        try (
//                PreparedStatement ps = connection.prepareStatement(sql)) {
//
//            ps.setString(1, semesterName);
//            ps.setString(2, startDate);
//            ps.setString(3, endDate);
//
//            int rowsAffected = ps.executeUpdate();
//            return rowsAffected > 0;
//        } catch (SQLException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
    /**
     *
     * @return
     */
    public List<Semester> getAllSemesters() {
        List<Semester> semesters = new ArrayList<>();
        String sql = "SELECT * FROM Semester";

        try (PreparedStatement ps = connection.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String semesterName = rs.getString("semester_name");
                String startDate = rs.getString("start_date");
                String endDate = rs.getString("end_date");
                semesters.add(new Semester(semesterName, startDate, endDate));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return semesters;
    }

    /**
     *
     * @param semesterName
     * @param startDate
     * @param endDate
     * @return
     */
    public boolean createSemester(String semesterName, String startDate, String endDate) {
        String sql = "INSERT INTO Semester (semester_name, start_date, end_date) VALUES (?, ?, ?)";
        try (
                PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, semesterName);
            ps.setString(2, startDate);
            ps.setString(3, endDate);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @param oldSemesterName
     * @param newSemesterName
     * @param startDate
     * @param endDate
     * @return
     */
    public boolean updateSemester(String oldSemesterName, String newSemesterName, String startDate, String endDate) {

        try {
            connection = getConnection();
            connection.setAutoCommit(false); // Bắt đầu transaction

            // Cập nhật semester_name trong bảng Class
            String sqlUpdateClass = "UPDATE Class SET semester_name = ? WHERE semester_name = ?";
            PreparedStatement psUpdateClass = connection.prepareStatement(sqlUpdateClass);
            psUpdateClass.setString(1, newSemesterName);
            psUpdateClass.setString(2, oldSemesterName);
            psUpdateClass.executeUpdate();

            // Cập nhật semester_name trong bảng Course
            String sqlUpdateCourse = "UPDATE Course SET semester_name = ? WHERE semester_name = ?";
            PreparedStatement psUpdateCourse = connection.prepareStatement(sqlUpdateCourse);
            psUpdateCourse.setString(1, newSemesterName);
            psUpdateCourse.setString(2, oldSemesterName);
            psUpdateCourse.executeUpdate();

            // Cập nhật semester_name, start_date, và end_date trong bảng Semester
            String sqlUpdateSemester = "UPDATE Semester SET semester_name = ?, start_date = ?, end_date = ? WHERE semester_name = ?";
            PreparedStatement psUpdateSemester = connection.prepareStatement(sqlUpdateSemester);
            psUpdateSemester.setString(1, newSemesterName);
            psUpdateSemester.setString(2, startDate);
            psUpdateSemester.setString(3, endDate);
            psUpdateSemester.setString(4, oldSemesterName);
            psUpdateSemester.executeUpdate();

            connection.commit(); // Commit transaction
            return true;
        } catch (SQLException e) {
            if (connection != null) {
                try {
                    connection.rollback(); // Rollback transaction nếu có lỗi
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
            return false;
        }
    }

    private boolean semesterNameExists(String semesterName) {
        String sql = "SELECT COUNT(*) FROM Semester WHERE semester_name = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, semesterName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     *
     * @param semesterName
     * @return
     */
    public Semester getSemester(String semesterName) {
        String sql = "SELECT * FROM Semester WHERE semester_name = ?";
        try (Connection connection = getConnection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, semesterName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Semester(
                            rs.getString("semester_name"),
                            rs.getString("start_date"),
                            rs.getString("end_date")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *
     * @param semesterName
     * @return
     */
    public boolean deleteSemester(String semesterName) {

        try {
            connection = getConnection();
            connection.setAutoCommit(false); // Bắt đầu transaction

            // Xóa các bản ghi trong bảng Quiz liên quan đến semester_name
            String sqlDeleteQuiz = "DELETE FROM Quiz WHERE class_id IN (SELECT class_id FROM Class WHERE semester_name = ?)";
            PreparedStatement psDeleteQuiz = connection.prepareStatement(sqlDeleteQuiz);
            psDeleteQuiz.setString(1, semesterName);
            psDeleteQuiz.executeUpdate();

            // Xóa các bản ghi trong bảng Class liên quan đến semester_name
            String sqlDeleteClass = "DELETE FROM Class WHERE semester_name = ?";
            PreparedStatement psDeleteClass = connection.prepareStatement(sqlDeleteClass);
            psDeleteClass.setString(1, semesterName);
            psDeleteClass.executeUpdate();

            // Xóa các bản ghi trong bảng Course liên quan đến semester_name
            String sqlDeleteCourse = "DELETE FROM Course WHERE semester_name = ?";
            PreparedStatement psDeleteCourse = connection.prepareStatement(sqlDeleteCourse);
            psDeleteCourse.setString(1, semesterName);
            psDeleteCourse.executeUpdate();

            // Xóa học kỳ
            String sqlDeleteSemester = "DELETE FROM Semester WHERE semester_name = ?";
            PreparedStatement psDeleteSemester = connection.prepareStatement(sqlDeleteSemester);
            psDeleteSemester.setString(1, semesterName);
            psDeleteSemester.executeUpdate();

            connection.commit(); // Commit transaction
            return true;
        } catch (SQLException e) {
            if (connection != null) {
                try {
                    connection.rollback(); // Rollback transaction nếu có lỗi
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
            return false;
        }
    }

    //////Course
    /**
     *
     * @param username
     * @return
     */
    public List<Course> getCoursesByTeacher(String username) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.course_code, c.title, ta.semester_name "
                + "FROM Teaching_Assignments ta "
                + "JOIN Course c ON ta.course_code = c.course_code AND ta.semester_name = c.semester_name "
                + "WHERE ta.username = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String courseCode = rs.getString("course_code");
                String title = rs.getString("title");
                String semesterName = rs.getString("semester_name");
                courses.add(new Course(courseCode, title, semesterName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    /**
     *
     * @param studentUsername
     * @return
     */
    public List<Course> getCoursesForStudent(String studentUsername) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.course_code, c.title, c.semester_name "
                + "FROM Course c "
                + "JOIN Class cl ON c.course_code = cl.course_code AND c.semester_name = cl.semester_name "
                + "JOIN Enrollment e ON cl.class_id = e.class_id AND cl.course_code = e.course_code AND cl.semester_name = e.semester_name "
                + "WHERE e.username = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, studentUsername);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String courseCode = rs.getString("course_code");
                String title = rs.getString("title");
                String semesterName = rs.getString("semester_name");
                courses.add(new Course(courseCode, title, semesterName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }

    /**
     *
     * @param courseCode
     * @param title
     * @param semesterName
     * @return
     */
    public boolean createCourse(String courseCode, String title, String semesterName) {
        String sql = "INSERT INTO Course (course_code, title, semester_name) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, courseCode);
            ps.setString(2, title);
            ps.setString(3, semesterName);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @param oldCourseCode
     * @param oldSemesterName
     * @param newCourseCode
     * @param title
     * @param newSemesterName
     * @return
     */
    public boolean updateCourse(String oldCourseCode, String oldSemesterName, String newCourseCode, String title, String newSemesterName) {
        String updateCourseSql = "UPDATE Course SET course_code = ?, title = ?, semester_name = ? WHERE course_code = ? AND semester_name = ?";
        String updateTeachingAssignmentsSql = "UPDATE Teaching_Assignments SET class_id = ? WHERE class_id IN (SELECT class_id FROM Class WHERE course_code = ? AND semester_name = ?)";

        try {
            connection.setAutoCommit(false); // Start transaction

            try (PreparedStatement psCourse = connection.prepareStatement(updateCourseSql); PreparedStatement psTeachingAssignments = connection.prepareStatement(updateTeachingAssignmentsSql)) {

                // Update Course details
                psCourse.setString(1, newCourseCode);
                psCourse.setString(2, title);
                psCourse.setString(3, newSemesterName);
                psCourse.setString(4, oldCourseCode);
                psCourse.setString(5, oldSemesterName);
                int rowsAffectedCourse = psCourse.executeUpdate();

                if (rowsAffectedCourse > 0) {
                    // Update Teaching_Assignments references
                    psTeachingAssignments.setString(1, newCourseCode);
                    psTeachingAssignments.setString(2, oldCourseCode);
                    psTeachingAssignments.setString(3, oldSemesterName);
                    psTeachingAssignments.executeUpdate();
                }

                connection.commit(); // Commit transaction
                return rowsAffectedCourse > 0;
            } catch (SQLException e) {
                connection.rollback(); // Rollback transaction on error
                e.printStackTrace();
                return false;
            } finally {
                connection.setAutoCommit(true); // Reset autocommit to default
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

//    public boolean deleteCourse(String courseCode, String semesterName) {
//        String sql = "DELETE FROM Course WHERE course_code = ? AND semester_name = ?";
//        try (PreparedStatement ps = connection.prepareStatement(sql)) {
//            ps.setString(1, courseCode);
//            ps.setString(2, semesterName);
//
//            int rowsAffected = ps.executeUpdate();
//            return rowsAffected > 0;
//        } catch (SQLException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
    /**
     *
     * @param courseCode
     * @param semesterName
     * @return
     */
    public boolean deleteCourse(String courseCode, String semesterName) {
        String deleteScoresSql = "DELETE s FROM Score s INNER JOIN Quiz q ON s.quiz_id = q.quiz_id INNER JOIN Class c ON q.class_id = c.class_id WHERE c.course_code = ? AND c.semester_name = ?";
        String deleteQuizzesSql = "DELETE q FROM Quiz q INNER JOIN Class c ON q.class_id = c.class_id WHERE c.course_code = ? AND c.semester_name = ?";
        String deleteTeachingAssignmentsSql = "DELETE FROM Teaching_Assignments WHERE class_id IN (SELECT class_id FROM Class WHERE course_code = ? AND semester_name = ?)";
        String deleteEnrollmentsSql = "DELETE e FROM Enrollment e INNER JOIN Class c ON e.class_id = c.class_id WHERE c.course_code = ? AND c.semester_name = ?";
        String deleteClassesSql = "DELETE FROM Class WHERE course_code = ? AND semester_name = ?";
        String deleteCourseSql = "DELETE FROM Course WHERE course_code = ? AND semester_name = ?";

        try {
            connection.setAutoCommit(false); // Start transaction

            // Delete from Score
            try (PreparedStatement psScores = connection.prepareStatement(deleteScoresSql)) {
                psScores.setString(1, courseCode);
                psScores.setString(2, semesterName);
                psScores.executeUpdate();
            }

            // Delete from Quiz
            try (PreparedStatement psQuizzes = connection.prepareStatement(deleteQuizzesSql)) {
                psQuizzes.setString(1, courseCode);
                psQuizzes.setString(2, semesterName);
                psQuizzes.executeUpdate();
            }

            // Delete from Teaching_Assignments
            try (PreparedStatement psTeachingAssignments = connection.prepareStatement(deleteTeachingAssignmentsSql)) {
                psTeachingAssignments.setString(1, courseCode);
                psTeachingAssignments.setString(2, semesterName);
                psTeachingAssignments.executeUpdate();
            }

            // Delete from Enrollment
            try (PreparedStatement psEnrollments = connection.prepareStatement(deleteEnrollmentsSql)) {
                psEnrollments.setString(1, courseCode);
                psEnrollments.setString(2, semesterName);
                psEnrollments.executeUpdate();
            }

            // Delete from Class
            try (PreparedStatement psClasses = connection.prepareStatement(deleteClassesSql)) {
                psClasses.setString(1, courseCode);
                psClasses.setString(2, semesterName);
                psClasses.executeUpdate();
            }

            // Delete from Course
            try (PreparedStatement psCourse = connection.prepareStatement(deleteCourseSql)) {
                psCourse.setString(1, courseCode);
                psCourse.setString(2, semesterName);
                int rowsAffected = psCourse.executeUpdate();

                if (rowsAffected > 0) {
                    connection.commit(); // Commit transaction
                    return true;
                } else {
                    connection.rollback(); // Rollback transaction on error
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                connection.rollback(); // Rollback transaction on error
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return false;
        } finally {
            try {
                connection.setAutoCommit(true); // Reset autocommit to default
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     *
     * @param courseCode
     * @param semesterName
     * @return
     */
    public Course getCourse(String courseCode, String semesterName) {
        String sql = "SELECT * FROM Course WHERE course_code = ? AND semester_name = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, courseCode);
            ps.setString(2, semesterName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Course(
                            rs.getString("course_code"),
                            rs.getString("title"),
                            rs.getString("semester_name")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *
     * @param teacherUsername
     * @param courseCode
     * @param semesterName
     * @return
     */
    public boolean assignTeacherToCourse(String teacherUsername, String courseCode, String semesterName) {
        String checkCourseSql = "SELECT 1 FROM Course WHERE course_code = ? AND semester_name = ?";
        String insertAssignmentSql = "INSERT INTO Teaching_Assignments (username, course_code, semester_name) VALUES (?, ?, ?)";

        try (PreparedStatement psCheck = connection.prepareStatement(checkCourseSql); PreparedStatement psInsert = connection.prepareStatement(insertAssignmentSql)) {

            // Check if course exists
            psCheck.setString(1, courseCode);
            psCheck.setString(2, semesterName);
            try (ResultSet rs = psCheck.executeQuery()) {
                if (!rs.next()) {
                    return false; // Course does not exist
                }
            }

            // Insert teaching assignment
            psInsert.setString(1, teacherUsername);
            psInsert.setString(2, courseCode);
            psInsert.setString(3, semesterName);

            int rowsAffected = psInsert.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @param semesterName
     * @return
     */
    public List<Course> getCoursesForSemester(String semesterName) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT course_code, title, semester_name FROM Course WHERE semester_name = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, semesterName);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    courses.add(new Course(
                            rs.getString("course_code"),
                            rs.getString("title"),
                            rs.getString("semester_name")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    /**
     *
     * @return
     */
    public List<Teacher> getAllTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        String sql = "SELECT * FROM Teacher";
        try (PreparedStatement ps = connection.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String department = rs.getString("department");
                String managedByManager = rs.getString("managed_by_manager");
                String googleId = rs.getString("google_id");
                teachers.add(new Teacher(username, password, name, email, department, managedByManager, googleId));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teachers;
    }

    ////////Student
    /**
     *
     * @param email
     * @return
     */
    public boolean checkStudentExists(String email) {
        try {
            String query = "SELECT * FROM Student WHERE email = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to add a new student
    /**
     *
     * @param email
     * @param name
     */
    public void addStudent(String email, String name) {
        try {
            String username = email.split("@")[0]; // Generate username from email
            String password = "default"; // Set default password or generate randomly

            // Insert into Student table
            String query = "INSERT INTO Student (username, password, name, email) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, name);
            ps.setString(4, email);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //////create class
    public List<Class> getClassDetails(String courseCode, String semesterName) {
        List<Class> classDetails = new ArrayList<>();
        String sql = "SELECT * FROM Class WHERE course_code = ? AND semester_name = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, courseCode);
            stmt.setString(2, semesterName);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Class classDetail = new Class();
                classDetail.setClassId(rs.getString("class_id"));
                classDetail.setRoom(rs.getString("room"));
                classDetail.setCourseCode(courseCode);  // Ensure courseCode is set
                classDetail.setSemesterName(semesterName);  // Ensure semesterName is set
                classDetails.add(classDetail);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return classDetails;
    }

    /**
     *
     * @param classId
     * @param courseCode
     * @param semesterName
     * @param room
     * @return
     */
    public boolean createClass(String classId, String courseCode, String semesterName, String room) {
        if (checkClassExists(classId, courseCode, semesterName)) {
            return false; // Class ID với course_code và semester_name đã tồn tại
        }
        String sql = "INSERT INTO Class (class_id, course_code, semester_name, room) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, classId);
            ps.setString(2, courseCode);
            ps.setString(3, semesterName);
            ps.setString(4, room);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @param teacherUsername
     * @param classId
     * @param courseCode
     * @param semesterName
     * @return
     */
    public boolean assignTeacherToClass(String teacherUsername, String classId, String courseCode, String semesterName) {
        if (!checkClassExists(classId, courseCode, semesterName)) {
            return false; // Lớp học không tồn tại
        }

        String sql = "INSERT INTO Teaching_Assignments (username, class_id, course_code, semester_name) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teacherUsername);
            ps.setString(2, classId);
            ps.setString(3, courseCode);
            ps.setString(4, semesterName);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     *
     * @param classId
     * @param courseCode
     * @param semesterName
     * @return
     */
    public boolean checkClassExists(String classId, String courseCode, String semesterName) {
        String sql = "SELECT 1 FROM Class WHERE class_id = ? AND course_code = ? AND semester_name = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, classId);
            ps.setString(2, courseCode);
            ps.setString(3, semesterName);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    ////////Question for Teacher
    // Method to get questions by teacher
    public List<Question> getQuestionsByTeacher(String teacherUsername) {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT * FROM Question WHERE teacher_username = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, teacherUsername);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Question question = new Question();
                question.setQuestionId(rs.getString("question_id"));
                question.setContent(rs.getString("content"));
                question.setCorrectAnswer(rs.getString("correct_answer"));
                question.setQuestionType(rs.getString("question_type"));
                question.setTeacherUsername(rs.getString("teacher_username"));
                questions.add(question);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    // Method to add a new question
    public void addQuestion(Question question) {
        String sql = "INSERT INTO Question (content, correct_answer, question_type, teacher_username) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, question.getContent());
            stmt.setString(2, question.getCorrectAnswer());
            stmt.setString(3, question.getQuestionType());
            stmt.setString(4, question.getTeacherUsername());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /////QUIZZ
    // Method to create a new quiz with questions
    public void createQuiz(Quiz quiz) {
        String quizSql = "INSERT INTO Quiz (quiz_id, class_id, course_code, semester_name, quiz_name, date, duration) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String questionSql = "INSERT INTO Question (content, correct_answer, question_type, teacher_username) VALUES (?, ?, ?, ?)";
        String quizQuestionSql = "INSERT INTO Quiz_Question (quiz_id, question_id) VALUES (?, ?)";

        try {
            connection.setAutoCommit(false); // Start transaction

            // Insert quiz
            try (PreparedStatement quizStmt = connection.prepareStatement(quizSql)) {
                quizStmt.setString(1, quiz.getQuizId());
                quizStmt.setString(2, quiz.getClassId());
                quizStmt.setString(3, quiz.getCourseCode());
                quizStmt.setString(4, quiz.getSemesterName());
                quizStmt.setString(5, quiz.getQuizName());
                quizStmt.setString(6, quiz.getQuizDate()); // Assuming quizDate is in YYYY-MM-DD format
                quizStmt.setString(7, quiz.getQuizDuration());
                quizStmt.executeUpdate();

                List<Question> questions = quiz.getQuestions();

                // Insert questions and quiz_question relation
                try (PreparedStatement questionStmt = connection.prepareStatement(questionSql, PreparedStatement.RETURN_GENERATED_KEYS); PreparedStatement quizQuestionStmt = connection.prepareStatement(quizQuestionSql)) {
                    for (Question question : questions) {
                        questionStmt.setString(1, question.getContent());
                        questionStmt.setString(2, question.getCorrectAnswer());
                        questionStmt.setString(3, question.getQuestionType());
                        questionStmt.setString(4, question.getTeacherUsername());
                        questionStmt.executeUpdate();

                        ResultSet questionGeneratedKeys = questionStmt.getGeneratedKeys();
                        if (questionGeneratedKeys.next()) {
                            int questionId = questionGeneratedKeys.getInt(1);

                            quizQuestionStmt.setString(1, quiz.getQuizId());
                            quizQuestionStmt.setInt(2, questionId);
                            quizQuestionStmt.executeUpdate();
                        }
                    }
                }
            }
            connection.commit(); // Commit transaction
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                connection.rollback(); // Rollback transaction in case of error
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    /////////////Student
    // Phương thức lấy danh sách sinh viên trong lớp
    public List<Student> getStudentsInClass(String classId, String courseCode, String semesterName) {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT s.username, s.name, s.email FROM Student s "
                + "JOIN Enrollment e ON s.username = e.username "
                + "WHERE e.class_id = ? AND e.course_code = ? AND e.semester_name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, classId);
            stmt.setString(2, courseCode);
            stmt.setString(3, semesterName);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setUsername(rs.getString("username"));
                student.setName(rs.getString("name"));
                student.setEmail(rs.getString("email"));
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    // Phương thức thêm sinh viên vào lớp
    public void addStudentToClass(String studentUsername, String classId, String courseCode, String semesterName) {
        String sql = "INSERT INTO Enrollment (username, class_id, course_code, semester_name) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, studentUsername);
            stmt.setString(2, classId);
            stmt.setString(3, courseCode);
            stmt.setString(4, semesterName);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
